__doc__ = """
Package holding files for Google Transit Feed Specification Schedule Viewer.
"""
# This package contains the data files for schedule_viewer.py, a script that
# comes with the transitfeed distribution. According to the thread
# "[Distutils] distutils data_files and setuptools.pkg_resources are driving
# me crazy" this is the easiest way to include data files. My experience
# agrees. - Tom 2007-05-29
